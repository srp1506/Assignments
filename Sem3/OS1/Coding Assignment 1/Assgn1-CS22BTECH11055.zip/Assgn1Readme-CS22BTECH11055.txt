Assignment - 1;

Name - Soham Rajesh Pawar;
Roll number - CS22BTECH11055;
Course ID - CS3510;
Operating System;

Cautions :

	Make sure the input file is always in the same folder as the executable;
	Sample input file has been included in the zip file for reference;
	
Directions :

	-> Enter "gcc Assgn1Src-CS22BTECH11055.c" on the terminal to compile;
	-> Enter the value of N and K in a file named "input.txt";
	-> Check the log files created on the execution of the program for verification;
-------------------------------------------------------------------------------------------------------------------------
