Lab Assignment - 3;

Name - Soham Rajesh Pawar;
Roll number - CS22BTECH11055;
Course ID - CS2323;
Computer Architecture;

Caution :

	Make sure the Header file included in the zip file is always in the same folder as the executable;
	
Directions :

	-> Enter "gcc lab.c -lm" on the terminal to compile;
	-> Enter the relative path of the input file;
	-> The converted assembly code will be displayed on pressing enter along with the original instructions for verification;

Note : 

	The instructions should be in hexadecimal format and each instruction should appear on a new line. No spaces between or before the hexadecimal code is allowed. Error handling has been taken into consideration but isn't as rigorous as one would usually see as nothing of the sort was explicitly stated in the problem statement;

Technicalities : 

	For the lui statements, the immediate is given in decimal format. The same statement is valid on RIPES simulator; ---------------------------------------------------------------------------------------------------------
