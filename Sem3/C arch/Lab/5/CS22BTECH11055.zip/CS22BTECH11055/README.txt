Lab Assignment - 5;

Name - Soham Rajesh Pawar;
Roll number - CS22BTECH11055;
Course ID - CS2323;
Computer Architecture;

Caution :

	Make sure the Header file included in the zip file is always in the same folder as the c file;
	
Directions :

	-> Enter "gcc Q(relevant question number).c" on the terminal to compile;
	-> Enter the relative path of the input file;
	-> The corrected assembly code + required cycles will be displayed on pressing enter along with the original instructions for verification;
---------------------------------------------------------------------------------------------------------
