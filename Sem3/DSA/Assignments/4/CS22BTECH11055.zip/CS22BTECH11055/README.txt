Coding Assignment - 3;

Name - Soham Rajesh Pawar ;
Roll number - CS22BTECH11055 ;
Course ID - CS2233 ;


Question 1 through 3 :
	--> Enter "gcc Q(question number)(part of the question to be compiled like a,b or c).c" to compile;
	--> Eg. gcc Q1a.c
	
Note :
	Follow the input format specified in the problem statement;
	Inputs should be positive for number of vertices and number of edges;
