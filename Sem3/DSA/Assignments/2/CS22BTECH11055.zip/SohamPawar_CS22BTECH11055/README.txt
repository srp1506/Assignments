Coding Assignment - 2;

Name - Soham Rajesh Pawar ;
Roll number - CS22BTECH11055 ;
Course ID - CS2233 ;

Question 1 :
    
    -> "gcc Q1.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;

Question 2 :

    -> "gcc Q2.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;

Question 3 :

    -> "gcc Q3.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;

Question 4 :
    
    -> "gcc Q4.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;
    
    Note : Each non leaf node should have two children

Question 5 : 
    
    -> "gcc Q5.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;

Question 6 :
    
    -> "gcc Q6.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;
 ---------------------------------------------------------------------------------------------------------
