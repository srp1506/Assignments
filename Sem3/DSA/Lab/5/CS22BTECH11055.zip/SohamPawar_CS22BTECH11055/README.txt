Lab Assignment - 5;

Name - Soham Rajesh Pawar ;
Roll number - CS22BTECH11055 ;
Course ID - CS2233 ;

Question 1 :
    
    -> "gcc Q1.c" to compile;
    -> Tree depends on the users input;
    -> The final answer will be displayed on pressing enter;
    
    Note : To show the implementation of the functions required by the question, the function calls have been hard coded with arbitrary(provided in the question) values. To implement the functions with different parameters changes will have to be made in the code itself. ---------------------------------------------------------------------------------------------------------
