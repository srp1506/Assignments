Lab Assignment - 1;

Name - Soham Rajesh Pawar ;
Roll number - CS22BTECH11055 ;
Course ID - CS2233 ;

Question 1 :
    
    -> "gcc Q1.c" to compile;
    -> The input must be continuous without any spaces between numbers(0 - 9) and operators as a string;
    -> The final answer will be displayed on pressing enter;

Question 2 :

    -> "gcc Q2.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;

Question 3 :

    -> "gcc Q3.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter. It will be the topmost elements of the two stacks entered(To access other elements of the two stacks appropriate code will have to be appended);

Question 4 :

    -> "gcc Q4.c" to compile;
   -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter. It will be an altered version of the stack entered obtained on performing enqueues and dequeues in a predefined order(Can be changed within the code);
    
    ->> TIME COMPLEXITY
    -> Enqueue operation: O(1) This is because it just adds one element to the top of the stack;
    -> Dequeue operation: O(n) This is because we need to transfer all elements in one stack to another and back to the main stack;
 ---------------------------------------------------------------------------------------------------------
