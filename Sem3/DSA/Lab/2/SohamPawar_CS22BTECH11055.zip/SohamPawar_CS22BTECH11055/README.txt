Lab Assignment - 2;

Name - Soham Rajesh Pawar ;
Roll number - CS22BTECH11055 ;
Course ID - CS2233 ;

Question 1 :
    
    -> "gcc Q1.c -lm" to compile;
    -> The input base must be changed within the code as it is hard coded.
    -> The final answer will be displayed on pressing enter; ---------------------------------------------------------------------------------------------------------
