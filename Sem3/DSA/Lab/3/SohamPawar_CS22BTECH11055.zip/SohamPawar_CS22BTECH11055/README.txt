Lab Assignment - 3;

Name - Soham Rajesh Pawar ;
Roll number - CS22BTECH11055 ;
Course ID - CS2233 ;

Question 1 :
    
    -> "gcc Q1.c" to compile;
    -> Hard coded for given tree;
    -> The final answer will be displayed on pressing enter;
    
Question 1(modified) :
    
    -> "gcc Q1_modified.c" to compile;
    -> Please provide the information asked by the terminal when the program is run;
    -> The final answer will be displayed on pressing enter;
    
    Note : The data value of the nodes should be positive, distinct and cannot exceed 1000;  ---------------------------------------------------------------------------------------------------------
