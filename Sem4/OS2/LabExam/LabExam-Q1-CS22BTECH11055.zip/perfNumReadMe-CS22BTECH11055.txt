Lab Exam Q1;

Name - Soham Rajesh Pawar;
Roll number - CS22BTECH11055;
Course ID - CS3523;
Operating System 2;

Cautions :

	Make sure the input file is always in the same folder as the executable;
	
Directions :
    -> Enter the input according to format in inp.txt.
	-> Enter "g++ perfNum-CS22BTECH11055.cpp" on the terminal to compile;
	-> Check the repective out files created on the execution of the program for verification;
---------------------------------------------------------------------------------------------------------------------------------------------------------